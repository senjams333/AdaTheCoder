"""Connects the app to the Ada The Coder website.

  * Courses, topics, lessons and videos edited in the website admin are downloaded in the
    background and used from the next time the app opens.
  * Tells the child and their grown-up when a new version of the app is ready.
  * Shows the website's "Message in the app" once per new message.

Only the standard library is used for the network part. If the computer is offline nothing
changes and the app keeps working with the lessons it has.
"""
import json
import os
import shutil
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request

from .config import APP_NAME, APP_VERSION, SERVER_URL, SYNC_EVERY
from .paths import data_dir

TIMEOUT = 8
USER_AGENT = f"AdaTheCoder/{APP_VERSION}"
NETWORK_ERRORS = (urllib.error.URLError, OSError, ValueError)


def videos_dir():
    path = os.path.join(data_dir(), "videos")
    os.makedirs(path, exist_ok=True)
    return path


def characters_dir():
    """Pictures of themes made in the website admin with their own characters."""
    path = os.path.join(data_dir(), "characters")
    os.makedirs(path, exist_ok=True)
    return path


def platform_key():
    if sys.platform.startswith("win"):
        return "windows"
    if sys.platform == "darwin":
        return "mac"
    return "other"


def _cache_path():
    return os.path.join(data_dir(), "courses_cache.json")


def _state_path():
    return os.path.join(data_dir(), "sync_state.json")


def _read_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def _write_json(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, path)


def saved_courses():
    """Courses downloaded on an earlier run, or [] if there are none."""
    return (_read_json(_cache_path(), None) or {}).get("courses") or []


# ------------------------------------------------------------------ talking to the website
def _is_local(url):
    host = (urllib.parse.urlsplit(url).hostname or "").lower()
    return host in ("localhost", "::1") or host.startswith("127.") or host.startswith("192.168.") or host.startswith("10.")


def _open(req, timeout):
    """Opens a web address. A website on this computer (or the home network) is reached directly,
    even when the computer has a proxy set up, which would otherwise block it."""
    if _is_local(req.full_url):
        return urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req, timeout=timeout)
    return urllib.request.urlopen(req, timeout=timeout)


# the app's log-in token (web_app.py sets it): with it, the website sends the themes the family bought in full
_app_token = ""


def set_app_token(token):
    global _app_token
    _app_token = token or ""


def _get_json(path, params=None):
    url = SERVER_URL.rstrip("/") + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    if _app_token:
        headers["Authorization"] = "Bearer " + _app_token
    req = urllib.request.Request(url, headers=headers)
    with _open(req, TIMEOUT) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _download(url, dest):
    tmp = dest + ".part"
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with _open(req, 60) as resp, open(tmp, "wb") as out:
        shutil.copyfileobj(resp, out, 1024 * 256)
    os.replace(tmp, dest)


def _fetch_videos(courses):
    """Downloads the lesson videos that aren't on this computer yet: the MP4, and the WebM copy the app's window
    plays (the website makes it with ffmpeg). Returns (every video file name the lessons use, whether any arrived).
    A download that fails or is cut off is simply tried again at the next check."""
    videos = videos_dir()
    wanted, got = set(), False
    for course in courses:
        for lesson in course.get("lessons") or []:
            video = lesson.get("video") or {}
            for file_key, url_key in (("file", "url"), ("webm_file", "webm_url")):
                if video.get(file_key) and video.get(url_key):
                    name = os.path.basename(video[file_key])
                    wanted.add(name)
                    dest = os.path.join(videos, name)
                    if not os.path.exists(dest):
                        try:
                            _download(video[url_key], dest)
                            got = True
                        except NETWORK_ERRORS:
                            try:
                                os.remove(dest + ".part")      # a half-finished download is started again next time
                            except OSError:
                                pass
    return wanted, got


def sync_courses(force=False):
    """Downloads the courses (with their lessons and any new videos). Returns True if anything changed.
    A paid theme the family hasn't bought comes with only its free lessons; the rest arrive once it's bought
    (force=True right after buying: everything is asked for again)."""
    cache = _read_json(_cache_path(), {})
    try:
        data = _get_json("/api/v3/courses", {"since": "" if force else cache.get("revision", "")})
    except NETWORK_ERRORS:
        return False
    if data.get("unchanged") or not data.get("courses"):
        # nothing new on the website, but a video that didn't finish downloading last time is fetched now
        return bool(cache.get("courses")) and _fetch_videos(cache["courses"])[1]
    videos = videos_dir()
    wanted, _ = _fetch_videos(data["courses"])
    pictures = characters_dir()
    for course in data["courses"]:
        # the theme's own characters, and its card picture (the cover the admin uploaded)
        for char in (course.get("characters") or []) + ([course["cover"]] if isinstance(course.get("cover"), dict) else []):
            name = os.path.basename(char.get("file") or "")
            if name and char.get("url") and not os.path.exists(os.path.join(pictures, name)):
                try:
                    _download(char["url"], os.path.join(pictures, name))
                except NETWORK_ERRORS:
                    pass  # the theme shows emoji (or, for the cover, its characters) until the picture arrives
    _write_json(_cache_path(), {"revision": data.get("revision"), "courses": data["courses"]})
    for name in os.listdir(videos):  # tidy away videos no lesson uses any more
        if name not in wanted:
            try:
                os.remove(os.path.join(videos, name))
            except OSError:
                pass
    return True


def login(email, password):
    """Checks the parent's email and password with the website.
    Returns {"ok": True, "name", "email", "licences": [theme ids]}, {"ok": False, "error"} for a wrong
    password, or None when the website can't be reached."""
    body = json.dumps({"email": email, "password": password}).encode("utf-8")
    req = urllib.request.Request(SERVER_URL.rstrip("/") + "/api/v3/login", data=body, method="POST",
                                 headers={"User-Agent": USER_AGENT, "Content-Type": "application/json",
                                          "Accept": "application/json"})
    try:
        with _open(req, TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code in (400, 401, 403, 429):
            try:
                return {"ok": False, "error": json.loads(e.read().decode("utf-8")).get("error") or "Wrong email or password."}
            except ValueError:
                return {"ok": False, "error": "Wrong email or password."}
        return None
    except NETWORK_ERRORS:
        return None


def register(details):
    """Creates a parent account on the website (/api/v3/register).
    details: {"name", "email", "password", "city", "country", "consent": True}.
    Returns {"ok": True, "name", "email", "licences"}, {"ok": False, "errors": [...]}, or None when offline."""
    body = json.dumps(details).encode("utf-8")
    req = urllib.request.Request(SERVER_URL.rstrip("/") + "/api/v3/register", data=body, method="POST",
                                 headers={"User-Agent": USER_AGENT, "Content-Type": "application/json",
                                          "Accept": "application/json"})
    try:
        with _open(req, TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            answer = json.loads(e.read().decode("utf-8"))
        except ValueError:
            return None if e.code == 404 else {"ok": False, "errors": ["The website couldn't create the account."]}
        return {"ok": False, "errors": answer.get("errors") or ["The website couldn't create the account."]}
    except NETWORK_ERRORS:
        return None


def fetch_licences(app_token):
    """The family's paid themes, asked again with the app's token: {"licences": [...]} or None."""
    if not app_token:
        return None
    req = urllib.request.Request(SERVER_URL.rstrip("/") + "/api/v3/licences",
                                 headers={"User-Agent": USER_AGENT, "Authorization": "Bearer " + app_token})
    try:
        with _open(req, 10) as resp:
            answer = json.loads(resp.read().decode("utf-8"))
        return answer if answer.get("ok") else None
    except NETWORK_ERRORS + (ValueError,):
        return None


def redeem_licence(app_token, code, theme_id=""):
    """"I have a licence 🔑": {"ok": True, "theme", "licences"} or {"ok": False, "error"}; None when offline."""
    body = json.dumps({"licence": code, "theme": theme_id}).encode("utf-8")
    req = urllib.request.Request(SERVER_URL.rstrip("/") + "/api/v3/licence", data=body, method="POST",
                                 headers={"User-Agent": USER_AGENT, "Content-Type": "application/json",
                                          "Accept": "application/json", "Authorization": "Bearer " + app_token})
    try:
        with _open(req, TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 401:
            return {"ok": False, "error": "Please log out and log in again, then type the licence."}
        try:
            return json.loads(e.read().decode("utf-8"))
        except ValueError:
            return {"ok": False, "error": "The website couldn't check the licence. Please try again."}
    except NETWORK_ERRORS:
        return None


def pay_page(theme_id):
    """The website page for buying a theme: the parent logs in there, then pays with Razorpay or PayPal."""
    return f"{SERVER_URL.rstrip('/')}/pay?theme={urllib.parse.quote(theme_id)}"


def forgot_password(email):
    """Asks the website to email a password reset link (/api/auth/forgot-password).
    Returns True when the website accepted it, False when it said no, or None when it can't be reached.
    The website answers the same whether or not the email has an account, so nobody can probe for accounts."""
    body = json.dumps({"email": email}).encode("utf-8")
    req = urllib.request.Request(SERVER_URL.rstrip("/") + "/api/auth/forgot-password", data=body, method="POST",
                                 headers={"User-Agent": USER_AGENT, "Content-Type": "application/json",
                                          "Accept": "application/json"})
    try:
        with _open(req, TIMEOUT) as resp:
            resp.read()
            return True
    except urllib.error.HTTPError as e:
        return None if e.code == 404 else False
    except NETWORK_ERRORS:
        return None


def check_for_update():
    if platform_key() == "other":
        return None
    try:
        info = _get_json("/api/v1/app/latest", {"platform": platform_key(), "version": APP_VERSION})
    except NETWORK_ERRORS:
        return None
    return info if info.get("update_available") else None


def new_announcement():
    """The website's message for the app, if the child hasn't seen it yet."""
    try:
        answer = _get_json("/api/v1/announcement")
    except NETWORK_ERRORS:
        return ""
    message = (answer.get("message") or "").strip()
    _save_home(answer)
    state = _read_json(_state_path(), {})
    if not message or message == state.get("last_message"):
        return ""
    state["last_message"] = message
    _write_json(_state_path(), state)
    return message


def _home_pictures(chars):
    """Downloads the home characters' pictures the admin uploaded, if they aren't here yet. True if one arrived.
    Until a picture arrives (or with none set) the app shows the one built into it; a failed download is tried again."""
    got = False
    for ch in chars:
        name = os.path.basename(ch.get("file") or "")
        if name and ch.get("url") and not os.path.exists(os.path.join(characters_dir(), name)):
            try:
                _download(ch["url"], os.path.join(characters_dir(), name))
                got = True
            except NETWORK_ERRORS:
                pass
    return got


def _save_home(answer):
    """Keeps the home screen the admin set on the website (greeting, characters with their names and pictures, the
    break), and downloads the characters' pictures. Returns True if anything changed."""
    state = _read_json(_state_path(), {})
    chars = [{"name": str(c.get("name") or "").strip()[:30], "file": str(c.get("file") or ""), "url": str(c.get("url") or "")}
             for c in (answer.get("home_chars") or []) if isinstance(c, dict)][:3]
    home = {"welcome": (answer.get("welcome") or "").strip(), "theme": (answer.get("home_theme") or "").strip(),
            "break": answer.get("break") if isinstance(answer.get("break"), dict) else None, "chars": chars}
    arrived = _home_pictures(chars)
    if home == state.get("home"):
        return arrived
    state["home"] = home
    _write_json(_state_path(), state)
    return True


def refresh_home():
    """Fetches the home screen settings only (the repeating check). True if they changed."""
    try:
        return _save_home(_get_json("/api/v1/announcement"))
    except NETWORK_ERRORS:
        return False


def home_screen():
    """The greeting and the theme whose characters stand on the home screen, as the admin last set them."""
    home = _read_json(_state_path(), {}).get("home") or {}
    return {"welcome": home.get("welcome") or "Welcome to Ada The Coder", "theme": home.get("theme") or "",
            "break": home.get("break"),       # the break reminder the admin set (None: the app's own, every 30 minutes)
            "chars": home.get("chars") or []}  # the home characters' names and pictures the admin set


def run_checks():
    """Everything the app asks the website, in one go. Safe to run in a background thread."""
    return {"lessons_updated": sync_courses(), "update": check_for_update(), "message": new_announcement()}


# ------------------------------------------------------------------ pop-ups in the app
def start(window):
    """Call once the main window is showing. Checks the website without slowing the app down."""
    from PyQt5.QtCore import QTimer, QUrl
    from PyQt5.QtGui import QDesktopServices
    from PyQt5.QtWidgets import QMessageBox

    results = {}
    worker = threading.Thread(target=lambda: results.update(run_checks()), daemon=True)
    worker.start()
    timer = QTimer(window)

    def show_results():
        if worker.is_alive():
            return
        timer.stop()
        update = results.get("update")
        if update:
            box = QMessageBox(window)
            box.setWindowTitle(APP_NAME)
            box.setIcon(QMessageBox.Information)
            text = f"A new version of {APP_NAME} ({update['latest_version']}) is ready! 🎉\n\nAsk a grown-up to download it."
            if update.get("required"):
                text = (f"Please update {APP_NAME} to version {update['latest_version']} so everything keeps "
                        "working.\n\nAsk a grown-up to download it.")
            if update.get("notes"):
                text += f"\n\nWhat's new: {update['notes']}"
            box.setText(text)
            open_btn = box.addButton("Open download page", QMessageBox.AcceptRole)
            box.addButton("Later", QMessageBox.RejectRole)
            box.exec_()
            if box.clickedButton() is open_btn and update.get("download_page"):
                QDesktopServices.openUrl(QUrl(update["download_page"]))
        if results.get("lessons_updated"):
            window.reload_courses()   # new themes and lessons appear straight away
        else:
            window.apply_theme()      # the home screen greeting and characters the admin set
        if results.get("message"):
            QMessageBox.information(window, APP_NAME, results["message"])

    timer.timeout.connect(show_results)
    timer.start(500)
    window._sync_timer = timer  # keep a reference so it isn't garbage-collected

    # Keep checking while the app is open, so themes and lessons the admin adds or edits arrive by themselves.
    repeat = QTimer(window)
    repeat.timeout.connect(lambda: check_now(window, quiet=True))
    repeat.start(SYNC_EVERY * 1000)
    window._sync_repeat = repeat


def check_now(window, quiet=False):
    """Downloads new or changed themes, lessons and videos now ("Check for new lessons" in the menu).
    quiet: no pop-up (the automatic check)."""
    from PyQt5.QtCore import QTimer
    from PyQt5.QtWidgets import QMessageBox

    if getattr(window, "_checking", False):
        return
    window._checking = True
    result = {}
    worker = threading.Thread(target=lambda: result.update(changed=sync_courses(), home=refresh_home(), online=_online()), daemon=True)
    worker.start()
    timer = QTimer(window)

    def done():
        if worker.is_alive():
            return
        timer.stop()
        window._checking = False
        if result.get("changed") or not quiet:
            window.reload_courses()   # (a manual check always refreshes what's on screen)
        elif result.get("home"):
            window.apply_theme()      # the admin changed the home screen's greeting or characters
        window.refresh_licences()     # a theme paid for on the website shows Purchased
        if quiet:
            return
        if not result.get("online"):
            QMessageBox.warning(window, APP_NAME, f"Can't reach the website: {SERVER_URL}\n\n"
                                "If you're testing on this computer, start the website first "
                                "(test_on_my_computer.sh starts both).")
            return
        from .lessons import load_courses
        names = "\n".join(f"  • {c['name']}  ({len(c['lessons'])} lessons)" for c in load_courses())
        head = "New themes and lessons are here! ✨" if result.get("changed") else "You have the newest lessons. 👍"
        wait = "\nThey'll appear when you go back to 🏠 Home." if getattr(window, "_reload_waiting", False) else ""
        QMessageBox.information(window, APP_NAME, f"{head}{wait}\n\nWebsite: {SERVER_URL}\nThemes:\n{names}\n\n"
                                "A theme only shows here when it's ticked \"Show this theme in the app\" "
                                "and has at least one live lesson.")
    timer.timeout.connect(done)
    timer.start(300)
    window._check_timer = timer


def _online():
    try:
        _get_json("/api/v1/announcement")
        return True
    except NETWORK_ERRORS:
        return False


# ------------------------------------------------------------------ "python run.py --check"
def diagnose():
    """Prints, step by step, whether the app can reach the website and what it gets. No window needed."""
    import traceback
    from .lessons import load_courses
    print(f"Ada The Coder {APP_VERSION}: connection check")
    print(f"1. Website the app uses: {SERVER_URL}")
    src = "--server / server_url.txt" if os.environ.get("ADA_SERVER_URL") or os.path.exists(
        os.path.join(data_dir(), "server_url.txt")) else "built in (config.py)"
    print(f"   (set by: {src}; data folder: {data_dir()})")
    proxies = {k: v for k, v in os.environ.items() if k.lower() in ("http_proxy", "https_proxy", "no_proxy")}
    if proxies:
        print(f"   Proxy settings on this computer: {proxies}" + (" (skipped for this local website)" if _is_local(SERVER_URL) else ""))
    ok = True
    for step, path in (("2. Website answers", "/api/v1/announcement"), ("3. Themes feed", "/api/v3/courses")):
        url = SERVER_URL + path
        try:
            req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
            with _open(req, TIMEOUT) as resp:
                raw = resp.read().decode("utf-8", "replace")
            data = json.loads(raw)
            if path.endswith("courses"):
                themes = data.get("courses") or []
                print(f"{step}: OK, {len(themes)} themes")
                for c in themes:
                    print(f"     - {c.get('id')}: {c.get('name')}  ({len(c.get('lessons') or [])} lessons, pack {c.get('pack')})")
            else:
                print(f"{step}: OK")
        except urllib.error.HTTPError as e:
            ok = False
            print(f"{step}: FAILED, the website answered {e.code} for {url}")
            if e.code == 404:
                print("   This address answers, but it isn't the Ada The Coder website (or it's an older version of it).")
            else:
                print("   " + e.read().decode("utf-8", "replace")[:400].replace("\n", "\n   "))
        except ValueError:
            ok = False
            print(f"{step}: FAILED, {url} did not send JSON (is this the Ada The Coder website?). It sent:")
            print("   " + raw[:300].replace("\n", " "))
        except Exception as e:  # noqa: BLE001 - this is a diagnosis, show everything
            ok = False
            print(f"{step}: FAILED, can't reach {url}: {e!r}")
            if _is_local(SERVER_URL):
                print("   Is the website running? Start it with:  bash test_on_my_computer.sh")
            break
    if ok:
        try:
            changed = sync_courses()
            print(f"4. Download into the app: OK ({'new changes saved' if changed else 'already up to date'})")
            print("5. Themes the app will show:")
            for c in load_courses():
                print(f"     - {c['name']}  ({len(c['lessons'])} lessons)")
        except Exception:  # noqa: BLE001
            print("4. Download into the app: FAILED")
            traceback.print_exc()
    print("Done. If something failed, send this whole text.")
    return 0 if ok else 1
